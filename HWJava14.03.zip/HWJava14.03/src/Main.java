import java.util.Scanner;

public class Main {
    // 1 уровень сложности: Проект 1
    //1 Пользователь вводит трёхзначное число.
    //2 Программа должна вывести на экран все цифры этого числа. Какждая цифра должна быть выведена в отдельной строчке.
    //

    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Please enter a three-digit number");
        int number = scr.nextInt();

        System.out.println(number/100);
        System.out.println((number/10)%10);
        System.out.println(number%10);
    }
}