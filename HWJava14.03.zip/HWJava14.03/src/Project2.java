import java.util.Random;

public class Project2 {

    //Проект 2
    //Компьютер генерирует три произвольных числа из диапазона от 0 до 999.
    //Найдите сумму чисел, выведите на экран.
    //Найдите произведение чисел, выведите на экран.
    public static void main(String[] args) {
        Random rnd = new Random();
        int a = rnd.nextInt(1000);
        int b = rnd.nextInt(1000);
        int c = rnd.nextInt(1000);
        System.out.println("Perwoe chislo = :" + a + ", Wtoroe chislo = :" + b + ", Tretje chislo = :" + c);
        System.out.println("Summa trech sgenerirowannich chisel = :" + (a + b + c));
        System.out.println("Summa trech sgenerirowannich chisel = :" + (a * b * c));



    }
}
